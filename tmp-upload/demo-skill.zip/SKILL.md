# Demo Upload Skill

This upload proves the SKILL.md ingestion flow works end to end.