const fs = require('fs');
const path = require('path');
const file = path.join(process.env.HOME, '.openclaw/workspace/memory/heartbeat-state.json');

try {
  let data = JSON.parse(fs.readFileSync(file, 'utf8'));
  data.lastLogWrite = 1773049808; // current time
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
  console.log('updated');
} catch(e) {
  console.error(e);
}
