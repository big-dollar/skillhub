# HEARTBEAT.md

# Keep this file empty (or with only comments) to skip heartbeat API calls.

# Add tasks below when you want the agent to check something periodically.

## 每次心跳必检：日志兜底写入

- 读取 heartbeat-state.json 中的 lastLogWrite 字段
- 如果距今超过 15 分钟，且当前 session 有实质性内容，追加写入 memory/YYYY-MM-DD.md
- 写完后更新 lastLogWrite 为当前时间
- 如果距今不足 15 分钟，跳过

## 每周首次心跳：记忆蒸馏

- 读取 heartbeat-state.json 中的 lastWeeklyTasks
- 如果不是当前周，执行蒸馏：
  1. 读取近7天的 memory/YYYY-MM-DD.md
  2. 提炼值得长期保留的信息
  3. 更新 MEMORY.md：补充新内容，删除或标注过期条目
  4. 更新 lastWeeklyTasks 为当前周次（如 2026-W10）
- 写入标准：只保留3个月后仍有价值的内容
