#!/usr/bin/env node
import { setTimeout } from "timers/promises";

function usage() {
  console.error(`Usage: search.mjs "query" [-n 5] [--deep] [--topic general|news] [--days 7]`);
  process.exit(2);
}

const args = process.argv.slice(2);
if (args.length === 0 || args[0] === "-h" || args[0] === "--help") usage();

// If first arg is not a flag, treat as query
let query = "";
if (!args[0].startsWith("-")) {
  query = args[0];
} else {
  usage();
}

let n = 5;
let searchDepth = "basic";
let topic = "general";
let days = null;

for (let i = 1; i < args.length; i++) {
  const a = args[i];
  if (a === "-n") {
    n = Number.parseInt(args[i + 1] ?? "5", 10);
    i++;
    continue;
  }
  if (a === "--deep") {
    searchDepth = "advanced";
    // continue; // Corrected logic: --deep is a flag, no value
  } else if (a === "--topic") {
    topic = args[i + 1] ?? "general";
    i++;
  } else if (a === "--days") {
    days = Number.parseInt(args[i + 1] ?? "7", 10);
    i++;
  } else if (a.startsWith("-")) {
    console.error(`Unknown arg: ${a}`);
    usage();
  }
}

const apiKey = (process.env.TAVILY_API_KEY ?? "").trim();
if (!apiKey) {
  console.error("Missing TAVILY_API_KEY");
  process.exit(1);
}

// Check for custom proxy settings
let agent;
const proxyUrl = process.env.HTTPS_PROXY || process.env.HTTP_PROXY;
if (proxyUrl) {
  try {
    const { HttpsProxyAgent } = await import('https-proxy-agent');
    agent = new HttpsProxyAgent(proxyUrl);
  } catch (e) {
    console.warn("Proxy set but https-proxy-agent not found, proceeding without proxy");
  }
}

const body = {
  api_key: apiKey,
  query: query,
  search_depth: searchDepth,
  topic: topic,
  max_results: n,
  include_answer: true,
  include_raw_content: false,
};

if (topic === "news" && days) {
  body.days = days;
}

// Add simple retry logic
async function fetchWithRetry(url, options, retries = 3) {
  for (let i = 0; i < retries; i++) {
    try {
      // Create an AbortController for timeout
      const controller = new AbortController();
      const timeoutId = setTimeout(15000, () => controller.abort()); // 15s timeout

      const res = await fetch(url, { ...options, signal: controller.signal });
      return res;
    } catch (err) {
      if (i === retries - 1) throw err;
      console.error(`Attempt ${i + 1} failed: ${err.message}. Retrying...`);
      await setTimeout(2000 * (i + 1)); // Backoff
    }
  }
}

try {
  const resp = await fetch("https://api.tavily.com/search", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(body),
    // ...(agent ? { agent } : {}), // Remove custom agent for now
    // keepalive: true, // Remove keepalive
  });

  if (!resp.ok) {
    const text = await resp.text().catch(() => "");
    throw new Error(`Tavily Search failed (${resp.status}): ${text}`);
  }

  const data = await resp.json();

  if (data.answer) {
    console.log("## Answer\n");
    console.log(data.answer);
    console.log("\n---\n");
  }

  const results = (data.results ?? []).slice(0, n);
  console.log("## Sources\n");

  for (const r of results) {
    const title = String(r?.title ?? "").trim();
    const url = String(r?.url ?? "").trim();
    const content = String(r?.content ?? "").trim();
    const score = r?.score ? ` (relevance: ${(r.score * 100).toFixed(0)}%)` : "";
    
    if (!title || !url) continue;
    console.log(`- **${title}**${score}`);
    console.log(`  ${url}`);
    if (content) {
      console.log(`  ${content.slice(0, 300)}${content.length > 300 ? "..." : ""}`);
    }
    console.log();
  }
} catch (error) {
  console.error("Error executing search:", error);
  process.exit(1);
}
