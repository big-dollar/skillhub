---
name: jenkins
description: Interact with Jenkins CI/CD server via REST API. Use when you need to trigger builds, check build status, view console output, manage jobs, or monitor Jenkins nodes and queue. Supports deployment to different Jenkins instances via environment variables.
---

# Jenkins

Interact with Jenkins CI/CD server through REST API.

## 磨铁项目配置

- **URL**: http://ci.xiron.motie.cn
- **用户**: admin
- **API Token**: 1183b736c2083c5895bd5fcb55da0d365b

### 项目与Job对应关系

| 项目 | Jenkins Job 路径 |
|------|-----------------|
| middle-end | middle-end/middle-end |
| goods-supply | goods_supply/goods-supply-dao, goods_supply/goods-supply-service, goods_supply/goods-supply-rpc-service, goods_supply/goods-supply-api, goods_supply/goods-supply-scheduler |
| presale-rpc-service | presale/presale-rpc-service |
| presale-api | presale/presale-api |
| presale-scheduler | presale/presale-scheduler |
| xiron-ecp-fe | ecp/xiron-ecp-fe |
| xiron-sale-fe | xiron-mgr-sell/Sale-FE |
| xiron-ecp (后端) | ecp/ecp-dao, ecp/ecp-rpc-service, ecp/ecp-api |
| xiron-ecp-ops | ecp/ecp-ops-dao, ecp/ecp-ops-rpc-service, ecp/ecp-ops-scheduler |
| promotions | promotions/promotions-dao, promotions/promotions-rpc-service, promotions/promotions-api, promotions/promotions-scheduler |

## Required environment variables

- `JENKINS_URL` (example: `https://jenkins.example.com`)
- `JENKINS_USER` (your Jenkins username)
- `JENKINS_API_TOKEN` (API token from Jenkins user settings)

## ⚠️ 重要：部署顺序与规则 (Strict Sequential Deployment)

**默认规则：严格顺序部署**
必须遵循：**等待前一个 job 真正执行完毕且状态为 SUCCESS 后，才能触发下一个 job！**

### ❌ 严禁做法
- 同时触发多个 job
- 触发后只检查 `lastBuild` 而不确认是否为新触发的构建
- 看到 `inQueue` 或 `building` 就认为“已启动”并立即继续下一个
- 不等待构建结果（SUCCESS/FAILURE）就继续

### ✅ 正确做法 (Python 示例)

1. **获取当前构建号**：触发前先记录 `old_build_number`
2. **触发构建**：调用 build API
3. **等待新构建启动**：轮询直到 `lastBuild.number > old_build_number`
4. **等待构建完成**：轮询新构建的状态，直到 `building: false`
5. **验证结果**：只有 `result: "SUCCESS"` 才继续下一个任务，否则**立即终止**

```python
import time
import requests

def strict_deploy(job_path):
    # 1. 获取当前最新构建号
    info = requests.get(f"{JENKINS_URL}/job/{job_path}/api/json", auth=AUTH).json()
    old_number = info['lastBuild']['number']
    
    # 2. 触发构建
    requests.post(f"{JENKINS_URL}/job/{job_path}/build", auth=AUTH)
    
    # 3. 等待新构建生成 (关键步骤！防止读取到旧的构建结果)
    new_number = 0
    while True:
        info = requests.get(f"{JENKINS_URL}/job/{job_path}/api/json", auth=AUTH).json()
        if info['lastBuild']['number'] > old_number:
            new_number = info['lastBuild']['number']
            break
        time.sleep(2)
        
    # 4. 等待构建完成
    while True:
        build_info = requests.get(f"{JENKINS_URL}/job/{job_path}/{new_number}/api/json", auth=AUTH).json()
        if not build_info['building']:
            result = build_info['result']
            if result == 'SUCCESS':
                print(f"✅ {job_path} #{new_number} 成功")
                return True
            else:
                print(f"❌ {job_path} #{new_number} 失败: {result}")
                return False # 停止后续部署
        time.sleep(5)
```

## List jobs

```bash
curl -s -u admin:1183b736c2083c5895bd5fcb55da0d365b "http://ci.xiron.motie.cn/api/json?tree=jobs[name,url]"
```

## Trigger build

```bash
curl -s -u admin:1183b736c2083c5895bd5fcb55da0d365b -X POST "http://ci.xiron.motie.cn/job/folder/job/my-job/build"
```

## Check build status

```bash
curl -s -u admin:1183b736c2083c5895bd5fcb55da0d365b "http://ci.xiron.motie.cn/job/folder/job/my-job/lastBuild/api/json" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('number'), d.get('result', '运行中'))"
```

## View queue

```bash
curl -s -u admin:1183b736c2083c5895bd5fcb55da0d365b "http://ci.xiron.motie.cn/queue/api/json"
```

### 返回给用户的信息格式

| 项目 | 模块 | 构建号 | 状态 | 开始时间 | 结束时间 | 耗时 |
|------|------|--------|------|----------|----------|------|
| xxx | xxx-dao | #123 | ✅ SUCCESS | 18:00:01 | 18:02:30 | 149s |

**必须包含：构建号、真实状态（SUCCESS/FAILURE/ABORTED）、开始/结束时间、耗时**

## Notes

- URL and credentials are variables by design for cross-environment deployment.
- API responses are output as JSON.
- For parameterized builds, use `--params` with JSON string.
