#!/bin/bash

# Jenkins部署定时任务
# 部署顺序：
# 1. middle-end
# 2. goods-supply-dao -> goods-supply-service -> goods-supply-rpc-service -> goods-supply-api -> goods-supply-scheduler
# 3. xiron-ecp-fe

JENKINS_URL="http://ci.xiron.motie.cn"
JENKINS_USER="admin"
JENKINS_TOKEN="1183b736c2083c5895bd5fcb55da0d365b"

# 等待函数
wait_for_build() {
    local job_path=$1
    local max_wait=600  # 最多等待10分钟
    
    while true; do
        result=$(curl -s -u ${JENKINS_USER}:${JENKINS_TOKEN} "${JENKINS_URL}/${job_path}/lastBuild/api/json")
        status=$(echo "$result" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('result', 'running'))" 2>/dev/null || echo "running")
        
        if [ "$status" = "SUCCESS" ]; then
            echo "✅ 构建成功"
            return 0
        elif [ "$status" = "FAILURE" ]; then
            echo "❌ 构建失败"
            return 1
        elif [ "$status" = "ABORTED" ]; then
            echo "⚠️ 构建中止"
            return 1
        fi
        
        sleep 10
    done
}

echo "========== 开始部署 =========="
echo "开始时间: $(date '+%Y-%m-%d %H:%M:%S')"

# 1. 部署 middle-end
echo ""
echo ">>> 1. 部署 middle-end"
curl -s -u ${JENKINS_USER}:${JENKINS_TOKEN} -X POST "${JENKINS_URL}/job/middle-end/job/middle-end/build"
if wait_for_build "job/middle-end/job/middle-end"; then
    echo "middle-end 部署成功"
else
    echo "middle-end 部署失败，停止部署"
    exit 1
fi

# 2. 部署 goods-supply 系列
echo ""
echo ">>> 2. 部署 goods-supply-dao"
curl -s -u ${JENKINS_USER}:${JENKINS_TOKEN} -X POST "${JENKINS_URL}/job/goods_supply/job/goods-supply-dao/build"
if wait_for_build "job/goods_supply/job/goods-supply-dao"; then
    echo "goods-supply-dao 部署成功"
else
    echo "goods-supply-dao 部署失败，停止部署"
    exit 1
fi

echo ""
echo ">>> 3. 部署 goods-supply-service"
curl -s -u ${JENKINS_USER}:${JENKINS_TOKEN} -X POST "${JENKINS_URL}/job/goods_supply/job/goods-supply-service/build"
if wait_for_build "job/goods_supply/job/goods-supply-service"; then
    echo "goods-supply-service 部署成功"
else
    echo "goods-supply-service 部署失败，停止部署"
    exit 1
fi

echo ""
echo ">>> 4. 部署 goods-supply-rpc-service"
curl -s -u ${JENKINS_USER}:${JENKINS_TOKEN} -X POST "${JENKINS_URL}/job/goods_supply/job/goods-supply-rpc-service/build"
if wait_for_build "job/goods_supply/job/goods-supply-rpc-service"; then
    echo "goods-supply-rpc-service 部署成功"
else
    echo "goods-supply-rpc-service 部署失败，停止部署"
    exit 1
fi

echo ""
echo ">>> 5. 部署 goods-supply-api"
curl -s -u ${JENKINS_USER}:${JENKINS_TOKEN} -X POST "${JENKINS_URL}/job/goods_supply/job/goods-supply-api/build"
if wait_for_build "job/goods_supply/job/goods-supply-api"; then
    echo "goods-supply-api 部署成功"
else
    echo "goods-supply-api 部署失败，停止部署"
    exit 1
fi

echo ""
echo ">>> 6. 部署 goods-supply-scheduler"
curl -s -u ${JENKINS_USER}:${JENKINS_TOKEN} -X POST "${JENKINS_URL}/job/goods_supply/job/goods-supply-scheduler/build"
if wait_for_build "job/goods_supply/job/goods-supply-scheduler"; then
    echo "goods-supply-scheduler 部署成功"
else
    echo "goods-supply-scheduler 部署失败，停止部署"
    exit 1
fi

# 3. 部署前端 xiron-ecp-fe
echo ""
echo ">>> 7. 部署 xiron-ecp-fe"
curl -s -u ${JENKINS_USER}:${JENKINS_TOKEN} -X POST "${JENKINS_URL}/job/ecp/job/xiron-ecp-fe/build"
if wait_for_build "job/ecp/job/xiron-ecp-fe"; then
    echo "xiron-ecp-fe 部署成功"
else
    echo "xiron-ecp-fe 部署失败"
    exit 1
fi

echo ""
echo "========== 部署完成 =========="
echo "完成时间: $(date '+%Y-%m-%d %H:%M:%S')"
