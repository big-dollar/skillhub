# USER.md - About Your Human

- **Name:** 刘远
- **What to call them:** 哥
- **Pronouns:** 
- **Timezone:** Asia/Shanghai
- **Notes:** 

## Context

_(慢慢了解～)_

## 部署任务查找规则
1. 先从 Jenkins 查找 job
2. 如果找不到，通过 git 仓库地址匹配
3. 如果还匹配不到，通过飞书通知用户
