import time
import sys
import requests
import json
from datetime import datetime

JENKINS_URL = "http://ci.xiron.motie.cn"
AUTH = ("admin", "1183b736c2083c5895bd5fcb55da0d365b")

# 定义任务列表（顺序执行）
JOBS = [
    "middle-end/job/middle-end",
    "goods_supply/job/goods-supply-dao",
    "goods_supply/job/goods-supply-service",
    "goods_supply/job/goods-supply-rpc-service",
    "goods_supply/job/goods-supply-api",
    "goods_supply/job/goods-supply-scheduler"
]

def get_job_info(job_path):
    """获取Job信息"""
    url = f"{JENKINS_URL}/job/{job_path}/api/json"
    try:
        res = requests.get(url, auth=AUTH, timeout=10)
        if res.status_code == 200:
            return res.json()
    except Exception as e:
        print(f"\nError getting job info: {e}")
    return None

def trigger_build(job_path):
    """触发构建"""
    url = f"{JENKINS_URL}/job/{job_path}/build"
    try:
        res = requests.post(url, auth=AUTH, timeout=10)
        return res.status_code in [200, 201]
    except Exception as e:
        print(f"\nError triggering build: {e}")
        return False

def get_build_status(job_path, build_number):
    """获取特定构建的状态"""
    url = f"{JENKINS_URL}/job/{job_path}/{build_number}/api/json"
    try:
        res = requests.get(url, auth=AUTH, timeout=10)
        if res.status_code == 200:
            return res.json()
    except:
        pass
    return None

def run_deploy():
    print("========== 开始严格串行部署 (后端) ==========")
    print(f"开始时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    deploy_records = []

    for i, job_path in enumerate(JOBS):
        job_name = job_path.split("/")[-1]
        print(f"\n--------------------------------------------------")
        print(f">>> [{i+1}/{len(JOBS)}] 正在处理: {job_name}")
        
        # 1. 获取当前最后的构建号
        job_info = get_job_info(job_path)
        if not job_info:
            print(f"❌ 无法获取 {job_name} 信息，终止部署")
            sys.exit(1)
            
        last_build = job_info.get("lastBuild")
        old_build_number = last_build["number"] if last_build else 0
        print(f"    当前最新构建号: #{old_build_number}")
        
        # 2. 触发构建
        print(f"    正在触发新构建...", end="", flush=True)
        if not trigger_build(job_path):
            print(f"\n❌ 触发 {job_name} 失败，终止部署")
            sys.exit(1)
        print(" 请求已发送")
            
        # 3. 等待新构建出现 (检测 lastBuild.number > old_build_number)
        print("    等待新构建任务启动...", end="", flush=True)
        new_build_number = 0
        wait_start = time.time()
        
        while True:
            # 最多等待 120 秒启动时间 (防止排队过久)
            if time.time() - wait_start > 120:
                print("\n❌ 等待新构建启动超时 (120s)，可能队列阻塞或触发失败")
                sys.exit(1)
                
            info = get_job_info(job_path)
            if info:
                current_last = info.get("lastBuild")
                # 检查是否有新的构建号生成
                if current_last and current_last["number"] > old_build_number:
                    new_build_number = current_last["number"]
                    print(f"\n    ✅ 捕获到新构建: #{new_build_number}")
                    break
                
                # 额外检查：如果在队列中
                in_queue = info.get("inQueue", False)
                if in_queue:
                    print("(排队中)", end="", flush=True)
            
            time.sleep(2)
            print(".", end="", flush=True)
            
        # 4. 循环等待构建完成
        print(f"    正在构建 #{new_build_number} (请耐心等待)...", end="", flush=True)
        build_start_ts = time.time()
        start_time_str = datetime.now().strftime('%H:%M:%S')
        
        while True:
            status_data = get_build_status(job_path, new_build_number)
            if not status_data:
                time.sleep(5)
                continue
                
            is_building = status_data.get("building", True)
            result = status_data.get("result")
            
            if not is_building:
                # 构建结束
                end_ts = time.time()
                end_time_str = datetime.now().strftime('%H:%M:%S')
                duration = int(end_ts - build_start_ts)
                print(f"\n    构建结束。耗时: {duration}秒")
                
                if result == "SUCCESS":
                    print(f"    ✅ {job_name} #{new_build_number} 部署成功！")
                    deploy_records.append({
                        "name": job_name,
                        "number": new_build_number,
                        "status": "SUCCESS",
                        "start": start_time_str,
                        "end": end_time_str,
                        "duration": f"{duration}s"
                    })
                    break # 跳出等待循环，继续下一个任务
                else:
                    print(f"    ❌ {job_name} #{new_build_number} 部署失败 (状态: {result})")
                    print("⛔ 停止后续部署任务")
                    sys.exit(1)
            
            # 还在构建中
            time.sleep(5)
            print(".", end="", flush=True)
            
    print("\n==================================================")
    print("🎉 所有后端项目部署完成！")
    print(f"完成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    # 打印汇总
    print("\n📋 部署汇总:")
    print(f"{'项目名称':<30} | {'构建号':<8} | {'状态':<10} | {'开始':<10} | {'结束':<10} | {'耗时'}")
    print("-" * 90)
    for rec in deploy_records:
        print(f"{rec['name']:<30} | #{rec['number']:<7} | {rec['status']:<10} | {rec['start']:<10} | {rec['end']:<10} | {rec['duration']}")

if __name__ == "__main__":
    run_deploy()
