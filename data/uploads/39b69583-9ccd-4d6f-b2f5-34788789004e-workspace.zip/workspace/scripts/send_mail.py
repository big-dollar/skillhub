import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import sys

# 从 TOOLS.md 中获取的账号信息
SMTP_SERVER = "smtp.exmail.qq.com"
SMTP_PORT = 465
SENDER_EMAIL = "laikan@motie.com"
SENDER_PASSWORD = "8ql6,yhY"

def send_email(to_email, subject, body_html):
    msg = MIMEMultipart("alternative")
    msg['From'] = SENDER_EMAIL
    msg['To'] = to_email
    msg['Subject'] = subject

    msg.attach(MIMEText(body_html, 'html'))

    try:
        server = smtplib.SMTP_SSL(SMTP_SERVER, SMTP_PORT)
        server.login(SENDER_EMAIL, SENDER_PASSWORD)
        server.sendmail(SENDER_EMAIL, to_email, msg.as_string())
        server.quit()
        print(f"Email successfully sent to {to_email}")
    except Exception as e:
        print(f"Failed to send email: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    if len(sys.argv) < 4:
        print("Usage: python send_mail.py <to_email> <subject> <body_html_file>")
        sys.exit(1)
        
    to_email = sys.argv[1]
    subject = sys.argv[2]
    body_file = sys.argv[3]
    
    with open(body_file, 'r', encoding='utf-8') as f:
        body_html = f.read()
        
    send_email(to_email, subject, body_html)
