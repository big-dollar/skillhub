import requests
import time
import sys
import argparse

JENKINS_URL = 'http://ci.xiron.motie.cn'
AUTH = ('admin', '1183b736c2083c5895bd5fcb55da0d365b')

def deploy(job_path):
    print(f'Starting deployment for {job_path}...')
    
    # 1. Get current build number
    try:
        info = requests.get(f'{JENKINS_URL}/job/{job_path}/api/json', auth=AUTH, timeout=10).json()
        old_number = info['lastBuild']['number']
        print(f'Current last build: #{old_number}')
    except Exception as e:
        print(f'Error getting job info: {e}')
        return False

    # 2. Trigger build
    try:
        requests.post(f'{JENKINS_URL}/job/{job_path}/build', auth=AUTH, timeout=10)
        print('Build triggered successfully.')
    except Exception as e:
        print(f'Error triggering build: {e}')
        return False

    # 3. Wait for new build to start
    print('Waiting for new build to start...')
    new_number = 0
    start_wait = time.time()
    while time.time() - start_wait < 60:  # 60s timeout for start
        try:
            info = requests.get(f'{JENKINS_URL}/job/{job_path}/api/json', auth=AUTH, timeout=5).json()
            if info['lastBuild']['number'] > old_number:
                new_number = info['lastBuild']['number']
                print(f'New build started: #{new_number}')
                break
        except Exception as e:
            # Only print unexpected errors, ignore typical polling errors
            pass
        time.sleep(2)
    
    if new_number == 0:
        print('Timeout waiting for build to start.')
        return False

    # 4. Wait for completion
    print(f'Monitoring build #{new_number}...')
    start_time = time.time()
    while True:
        try:
            build_info = requests.get(f'{JENKINS_URL}/job/{job_path}/{new_number}/api/json', auth=AUTH, timeout=5).json()
            if not build_info['building']:
                end_time = time.time()
                result = build_info['result']
                duration = int(end_time - start_time)
                build_url = build_info.get('url', 'N/A')  # FIXED: Use .get() and correct variable name
                
                print(f'Build finished.')
                print(f'Result: {result}')
                print(f'Duration: {duration}s')
                print(f'URL: {build_url}')
                
                if result == 'SUCCESS':
                    return True
                else:
                    return False
            time.sleep(5)
        except Exception as e:
            print(f'Error monitoring build: {e}')
            # Don't break loop on network glitch, just retry
            time.sleep(5)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Jenkins Deployment Script')
    parser.add_argument('job', help='Job path (e.g., middle-end/job/middle-end)')
    args = parser.parse_args()
    
    success = deploy(args.job)
    if not success:
        sys.exit(1)
