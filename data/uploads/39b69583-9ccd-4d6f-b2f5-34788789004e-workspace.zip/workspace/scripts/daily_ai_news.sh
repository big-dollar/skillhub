#!/bin/bash

# 确保在脚本出错时也能看到日志
LOG_FILE="/root/.openclaw/workspace/logs/cron_ai_news.log"
exec 1>>"$LOG_FILE" 2>&1

echo "----------------------------------------"
echo "开始执行: $(date)"

# 设置环境
export HOME=/root
export PATH=/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin
# 确保TAVILY API KEY可用
export TAVILY_API_KEY="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"

# 临时文件
TEMP_RAW="/tmp/ai_news_raw.json"

# 使用Tavily搜索最近的AI热点新闻
echo "正在搜索AI热点新闻..."
curl -s -X POST https://api.tavily.com/search \
  -H "Content-Type: application/json" \
  -d '{"api_key": "'$TAVILY_API_KEY'", "query": "Today global AI news latest breakthroughs models", "search_depth": "advanced", "topic": "news", "days": 2, "max_results": 7}' > $TEMP_RAW

# 检查搜索是否成功
if ! grep -q "results" $TEMP_RAW; then
    echo "警告: Tavily搜索失败或无结果"
    cat $TEMP_RAW
    MESSAGE="🦐 每日AI热点简报 ($(date '+%Y年%m月%d日'))\n\n获取AI新闻失败，请检查Tavily API或网络状态。\n\n---来自小虾"
else
    # 提取标题、URL和内容，用node将其格式化为飞书支持的富文本
    FORMATTED_NEWS=$(node -e "
      const data = require('fs').readFileSync('$TEMP_RAW', 'utf8');
      try {
        const json = JSON.parse(data);
        if (!json.results || json.results.length === 0) {
          console.log('今日暂无重大AI新闻。');
          process.exit(0);
        }
        let output = '';
        json.results.forEach((item, i) => {
          output += \`**\${i+1}. \${item.title}**\n\`;
          // 截取一段描述
          let desc = item.content || '';
          if(desc.length > 200) desc = desc.substring(0, 200) + '...';
          output += \`📝 \${desc}\n\`;
          output += \`🔗 [阅读详情](\${item.url})\n\n\`;
        });
        console.log(output);
      } catch(e) {
        console.log('解析新闻数据出错');
      }
    ")
    
    MESSAGE="🤖 **全球AI热点速递** ($(date '+%Y年%m月%d日'))\n\n$FORMATTED_NEWS\n\n— *你的AI助手 小虾 🦐*"
fi

# 发送到飞书
echo "正在发送消息..."
/usr/bin/openclaw message send \
  --channel feishu \
  --target ou_7e496f20cfad672d8ea5e9d205419b4f \
  --message "$MESSAGE"

# 清理临时文件
rm -f $TEMP_RAW

echo "发送完成: $(date)"
echo "----------------------------------------"