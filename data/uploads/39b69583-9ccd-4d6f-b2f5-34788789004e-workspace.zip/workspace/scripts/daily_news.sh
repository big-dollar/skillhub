#!/bin/bash

# 确保在脚本出错时也能看到日志
LOG_FILE="/root/.openclaw/workspace/logs/cron_news.log"
exec 1>>"$LOG_FILE" 2>&1

echo "----------------------------------------"
echo "开始执行: $(date)"

# 设置环境
export HOME=/root
export PATH=/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin

# 获取新闻内容（使用curl）
# 增加超时设置，避免卡住
NEWS_CONTENT=$(curl -s --max-time 30 "https://m.thepaper.cn/" 2>/dev/null | grep -oP '(?<=title">)[^<]+' | head -20)

if [ -z "$NEWS_CONTENT" ]; then
    echo "警告: 未能获取到新闻内容"
    NEWS_CONTENT="（暂时无法获取新闻内容，请检查网络或源站）"
fi

# 格式化消息
MESSAGE="🦐 每日热点简报 ($(date '+%Y年%m月%d日 %H:%M'))

$NEWS_CONTENT

---来自小虾"

# 发送到飞书
echo "正在发送消息..."
/usr/bin/openclaw message send \
  --channel feishu \
  --target ou_7e496f20cfad672d8ea5e9d205419b4f \
  --message "$MESSAGE"

echo "发送完成: $(date)"
echo "----------------------------------------"
