# Memory

## Preferences
- **Timezone**: Asia/Shanghai
- **Deployment**:
  - Prefer Python scripts for complex/parallel tasks over multiple tool calls.
  - **Jenkins Search**: Always traverse folders -> Check Git URL (match repo name) -> Ask.
  - **Jenkins Script**: Use `~/.openclaw/workspace/scripts/jenkins_deploy.py` (fixed bugs/timeouts).
- **Search**:
  - **Tavily**: PREFERRED (Key: tvly-dev-2nCB43...). Use for general search/news.
  - **Brave**: DO NOT USE (No key).
  - **Web Fetch**: Fallback. Use concurrency for multiple URLs.

## Environment
- **Jenkins**:
  - URL: http://ci.xiron.motie.cn
  - User: admin
  - Token: 1183b736c2083c5895bd5fcb55da0d365b
  - Projects: 
    - ECP: `xiron-ecp-fe`
    - Sales: `Sale-FE`, `SaleBi-FE`, `xiron-mgr-sell` (folder)
    - Middle-end: `mainapp-fe`, `middle-end`
    - Depend_Env: `xiron-mgr` (Git: .../xiron-mgr.git)
    - Digital Pub: `xiron-dp-web`
    - ESHOP: `eshop-manage-frontend`, `eshop-web-frontend`
- **XXL-JOB**:
  - URL: https://xxl-job.api.xiron.net.cn/xxl-job-admin/
  - Script: `~/.openclaw/skills/xxl-job/xxl-job.sh`
- **FTP**:
  - Host: ftp.xiron.net.cn (UTF-8 required)
  - Accounts: jswx, dangdang_rixiao, boku_shixiao, wenxuan_rixiao, jd_rixiao

## Skills
- **Data Standard Generator**: Installed 2026-03-03. For structured data docs.

## History
- **2026-03-07**:
  - Jenkins frontend project scan (optimized with concurrency).
  - Tavily API key configured and tested successfully.
  - Optimized web search strategy (Tavily > Web Fetch > Brave).
  - Jenkins deployment script fixed (`jenkins_deploy.py`).
  - Found hidden project `xiron-mgr` in `Depend_Env` via Git URL search.
- **2026-03-09**:
  - Wrote a new `feishu-sheet` skill template to extract data from standard Feishu Spreadsheets via Open API.
  - Resolved `ws connect failed` log spam by temporarily setting `plugins.entries.feishu.enabled = false`.
  - Generated Kingdee SQL queries joining `T_BD_MATERIAL`, `T_BD_MATERIAL_L`, `T_BD_MATERIALBASE`, and `T_ORG_ORGANIZATIONS_L` with rigorous barcode validation (`IS NULL`, `LTRIM=''`, and `LIKE '%[^0-9]%'`).
