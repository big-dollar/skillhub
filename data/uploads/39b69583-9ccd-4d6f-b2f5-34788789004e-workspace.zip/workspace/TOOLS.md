# TOOLS.md - Local Notes

Skills define _how_ tools work. This file is for _your_ specifics — the stuff that's unique to your setup.

## What Goes Here

Things like:

- Camera names and locations
- SSH hosts and aliases
- Preferred voices for TTS
- Speaker/room names
- Device nicknames
- Anything environment-specific

## Examples

```markdown
### Cameras

- living-room → Main area, 180° wide angle
- front-door → Entrance, motion-triggered

### SSH

- home-server → 192.168.1.100, user: admin

### TTS

- Preferred voice: "Nova" (warm, slightly British)
- Default speaker: Kitchen HomePod
```

### Jenkins

- **磨铁Jenkins**: http://ci.xiron.motie.cn
  - 用户: admin
  - Token: 1183b736c2083c5895bd5fcb55da0d365b

### xxl-job

- **任务调度中心**: https://xxl-job.api.xiron.net.cn/xxl-job-admin/
  - 用户: liuyuan
  - Skill: ~/.openclaw/skills/xxl-job/xxl-job.sh
  - 用法:
    - `search <关键词>` - 搜索任务
    - `trigger <job_id> [参数]` - 触发任务
    - `logs <job_id> [条数] [jobGroup]` - 查询任务执行日志
  - 示例:
    - `bash ~/.openclaw/skills/xxl-job/xxl-job.sh search 京东` - 搜索京东相关任务
    - `bash ~/.openclaw/skills/xxl-job/xxl-job.sh logs 608` - 查询任务 608 的执行日志
  - 注意: 查询日志需要 jobGroup 参数，默认 15，如遇权限问题可尝试 2, 9, 15

Skills are shared. Your setup is yours. Keeping them apart means you can update skills without losing your notes, and share skills without leaking your infrastructure.

### DataX-Web

- **任务调度平台**: http://10.1.0.51:18080/
  - 用户: liuyuan
  - Skill: `~/.openclaw/skills/datax-web/datax-web.sh`
  - 用法:
    - `list [关键词]` - 搜索任务（如：bash datax-web.sh list 谷子）
    - `trigger <job_id>` - 触发任务（如：bash datax-web.sh trigger 476）

### Email (WeChat Enterprise / Tencent Exmail)

- **Account**: laikan@motie.com
- **Password**: 8ql6,yhY

#### IMAP (Receiving)
- **Server**: imap.exmail.qq.com
- **Port**: 993 (SSL)

#### SMTP (Sending)
- **Server**: smtp.exmail.qq.com
- **Port**: 465 (SSL)

---

Add whatever helps you do your job. This is your cheat sheet.

### FTP 配置

| 客户名称 | FTP地址 | 用户名 | 密码 |
|---------|---------|--------|------|
| 锦瑟闻香 | ftp://ftp.xiron.net.cn/ | jswx | mt@Jswx |
| 当当 | ftp://ftp.xiron.net.cn/ | dangdang_rixiao | mt@dangdang_rixiao |
| 博库实销 | ftp://ftp.xiron.net.cn/ | boku_shixiao | mt@boku_shixiao |
| 文轩日销 | ftp://ftp.xiron.net.cn/ | wenxuan_rixiao | mt@wenxuan_rixiao |
| 京东日销 | ftp://ftp.xiron.net.cn/ | jd_rixiao | mt@jd_rixiao |

**使用方法：**
```bash
# 连接FTP
ftp ftp.xiron.net.cn
# 用户名: jswx
# 密码: mt@Jswx

# 或使用lftp
lftp -u jswx,mt@Jswx ftp://ftp.xiron.net.cn
```

**⚠️ 中文文件名编码问题：**
连接后需设置UTF-8编码，否则中文文件名会乱码：
```python
ftp.voidcmd('OPTS UTF8 ON')
```
