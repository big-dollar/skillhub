import time
import requests
import sys

# Configuration
JENKINS_URL = "http://ci.xiron.motie.cn"
AUTH = ("admin", "1183b736c2083c5895bd5fcb55da0d365b")

JOBS = [
    # Group 1: xiron-ecp
    "ecp/job/ecp-dao",
    # "ecp/job/ecp-service", # Skipped: Job not found in Jenkins
    "ecp/job/ecp-rpc-service",
    "ecp/job/ecp-api",
    
    # Group 2: xiron-ecp-ops
    "ecp/job/ecp-ops-dao",
    "ecp/job/ecp-ops-rpc-service",
    "ecp/job/ecp-ops-scheduler"
]

def get_job_info(job_path):
    url = f"{JENKINS_URL}/job/{job_path}/api/json"
    try:
        return requests.get(url, auth=AUTH).json()
    except Exception as e:
        print(f"Error fetching info for {job_path}: {e}")
        return None

def trigger_build(job_path):
    url = f"{JENKINS_URL}/job/{job_path}/build"
    print(f"🚀 触发构建: {job_path}")
    requests.post(url, auth=AUTH)

def monitor_build(job_path, old_number):
    print(f"⏳ 等待新构建启动: {job_path} (last was #{old_number})")
    
    # Wait for new build to appear
    new_number = 0
    start_wait = time.time()
    while time.time() - start_wait < 120: # 2 mins timeout for start
        info = get_job_info(job_path)
        if info and info['lastBuild']['number'] > old_number:
            new_number = info['lastBuild']['number']
            break
        time.sleep(2)
    
    if new_number == 0:
        print(f"❌ 超时：新构建未在2分钟内启动: {job_path}")
        return False

    print(f"🔨 构建 #{new_number} 运行中...")
    
    # Wait for completion
    while True:
        try:
            build_url = f"{JENKINS_URL}/job/{job_path}/{new_number}/api/json"
            build_info = requests.get(build_url, auth=AUTH).json()
            
            if not build_info.get('building', True):
                result = build_info.get('result')
                duration = build_info.get('duration', 0) / 1000.0
                timestamp = build_info.get('timestamp', 0)
                
                if result == 'SUCCESS':
                    print(f"✅ {job_path} #{new_number} 成功 (耗时: {duration:.1f}s)")
                    return True
                else:
                    print(f"❌ {job_path} #{new_number} 失败: {result}")
                    return False
            time.sleep(5)
        except Exception as e:
            print(f"⚠️ 监控异常: {e}, 重试...")
            time.sleep(5)

def main():
    print("开始按顺序部署项目...")
    
    for job in JOBS:
        print(f"\n--- 处理任务: {job} ---")
        info = get_job_info(job)
        if not info:
            print(f"❌ 无法获取任务信息，跳过: {job}")
            continue
            
        old_number = info['lastBuild']['number']
        trigger_build(job)
        
        success = monitor_build(job, old_number)
        if not success:
            print(f"\n⛔ 部署中断！任务 {job} 失败或超时。后续任务已取消。")
            sys.exit(1)
            
    print("\n✨ 所有部署任务已完成！")

if __name__ == "__main__":
    main()
