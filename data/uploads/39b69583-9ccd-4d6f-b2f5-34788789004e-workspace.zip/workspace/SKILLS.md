# SKILLS.md

## Jenkins Search & Deployment Strategy

- **Script Location**: `~/.openclaw/workspace/scripts/jenkins_deploy.py`
- **Usage**: `python3 ~/.openclaw/workspace/scripts/jenkins_deploy.py "job/path"`
- **Notes**:
  - Script handles build triggering, polling for new build number, and waiting for completion.
  - Returns exit code 0 on success, 1 on failure.
  - Includes timeout protection and correct variable handling.

## Jenkins Search Strategy

When asked to deploy a project (e.g., `xiron-mgr`):
1.  **Full Traversal**: Search ALL folders and subfolders. Do not assume location.
2.  **Git URL Match**: If no direct name match, check the Git repository URL of every job. Match the project name against the repo name.
    - **Example**: `xiron-mgr` was found in `Depend_Env/xiron-mgr` by matching Git URL `.../xiron-mgr.git`.
3.  **Ask Last**: Only ask the user if BOTH name match and Git URL match fail.

## Web Search Strategy

- **DO NOT** use `web_search` tool (Brave Search API) as no API key is available.
- **PREFERRED**: Use `tavily` for general web search and news. API Key is valid and working.
- **FALLBACK**: Use `web_fetch` with Python scripts (`ThreadPoolExecutor`) only if `tavily` fails or specific raw HTML parsing is needed.

## Tavily Configuration
- **API Key**: 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
