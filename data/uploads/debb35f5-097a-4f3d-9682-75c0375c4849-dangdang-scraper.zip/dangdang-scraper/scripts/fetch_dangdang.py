import argparse
import urllib.request
import json
import re
import sys

def get_html(url):
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'})
    try:
        response = urllib.request.urlopen(req, timeout=10)
        return response.read().decode('gbk', 'ignore')
    except Exception as e:
        print(f"Error fetching {url}: {e}", file=sys.stderr)
        return ""

def parse_html(html):
    items = []
    # 提取每个包含图书信息的 li 元素
    lis = re.findall(r'<div class="list_num.*?</li>', html, re.DOTALL)
    if not lis:
        lis = re.split(r'<div class="list_num', html)[1:]
    
    for li in lis:
        item = {}
        
        # 封面 URL
        img_match = re.search(r'<div class="pic">.*?<img src="(.*?)"', li, re.DOTALL)
        img_orig_match = re.search(r'data-original="(.*?)"', li, re.DOTALL)
        if img_orig_match and img_orig_match.group(1):
            item['cover_url'] = img_orig_match.group(1)
        elif img_match:
            item['cover_url'] = img_match.group(1)
            
        # 标题和购买链接
        name_match = re.search(r'<div class="name"><a href="(.*?)" target="_blank" title="(.*?)"', li, re.DOTALL)
        if name_match:
            item['link'] = name_match.group(1)
            item['title'] = name_match.group(2).strip()
            
        # 评论数量
        star_match = re.search(r'<div class="star">.*?<a href=".*?">([\d]+条评论)</a>', li, re.DOTALL)
        if star_match:
            item['comments'] = star_match.group(1)
            
        # 作者和出版社（通过 publisher_info 定位）
        pub_infos = re.findall(r'<div class="publisher_info">(.*?)</div>', li, re.DOTALL)
        if len(pub_infos) >= 1:
            # 匹配作者 (可能带有 title 或者没有)
            authors = re.findall(r'<a href=".*?" title="(.*?)" target="_blank">', pub_infos[0])
            if not authors:
                authors = re.findall(r'<a href=".*?" target="_blank">(.*?)</a>', pub_infos[0])
            if authors:
                item['author'] = authors[0].strip()
                
        if len(pub_infos) >= 2:
            # 匹配出版社
            pubs = re.findall(r'<a href=".*?" target="_blank">(.*?)</a>', pub_infos[1])
            if pubs:
                item['publisher'] = pubs[0].strip()
                
        if 'title' in item:
            items.append(item)
            
    return items

def main():
    parser = argparse.ArgumentParser(description="Fetch Dangdang Bestsellers")
    parser.add_argument('--pages', type=int, default=2, help='Number of pages to fetch (20 items per page)')
    parser.add_argument('--output', type=str, default='/tmp/dangdang_books.json', help='Output JSON file path')
    args = parser.parse_args()

    all_items = []
    # 这里以近7日畅销榜为例，如果需要抓取其他榜单，可以把基础 URL 做成参数传入
    base_url = "http://bang.dangdang.com/books/bestsellers/01.00.00.00.00.00-recent7-0-0-1-{}"
    
    for i in range(1, args.pages + 1):
        url = base_url.format(i)
        print(f"Fetching page {i}...", file=sys.stderr)
        html = get_html(url)
        if html:
            items = parse_html(html)
            all_items.extend(items)
            
    with open(args.output, 'w', encoding='utf-8') as f:
        json.dump(all_items, f, ensure_ascii=False, indent=2)
        
    print(f"Successfully saved {len(all_items)} items to {args.output}", file=sys.stderr)

if __name__ == '__main__':
    main()
