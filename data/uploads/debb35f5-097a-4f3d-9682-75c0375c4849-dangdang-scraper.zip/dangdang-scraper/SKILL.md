---
name: dangdang-scraper
description: 当当网图书排行榜抓取工具 (Dangdang Scraper)。用于快速抓取当当网图书排行榜（如近7日畅销榜、新书榜等）的数据，并支持一键写入到飞书多维表格。
---

# 当当网图书排行榜抓取工具 (Dangdang Scraper)

用于快速抓取当当网图书排行榜（如近7日畅销榜、新书榜等）的数据，并支持一键写入到飞书多维表格。

## 适用场景

1. 用户要求“抓取当当网排行榜”、“获取当当畅销书数据”。
2. 用户要求将当当网图书排行榜数据更新或写入到飞书多维表格。
3. 需要按排名、图书名称、作者、出版社、评论数和购买链接结构化提取当当榜单。

## 工具链和优化策略

1. **核心抓取策略 (Python 原生处理)**:
   - 由于当当网页面为 GBK 编码，直接使用 `curl` 可能会遇到乱码和解析困难的问题。
   - **最优解**：使用带有标准库的 `python3` 脚本（见 `scripts/fetch_dangdang.py`）。
   - 利用 `urllib.request` 携带 `User-Agent` 获取 HTML，再通过 `GBK` 解码，并利用正则表达式（或 BeautifulSoup）结构化提取图书数据。这样可以做到请求和解析一体化，大幅减少步骤和耗时。
   - 一次性爬取并输出格式化的 JSON 数据。

2. **多维表格写入策略**:
   - 表格建立：首先创建/更新飞书多维表格（包含图书名称、评论数量、作者、出版社、图书购买链接等字段）。
   - 批量写入：必须使用 `feishu_bitable_app_table_record` 的 `batch_create` 批量插入 API 接口（每次最大写入 50 条）。避免逐条调用 API 导致的限流和高延迟。

## 使用方法

### 第一步：运行爬虫脚本获取 JSON 数据
使用 `exec` 工具运行自带的 Python 脚本抓取榜单：
```bash
python3 ~/.openclaw/workspace/skills/dangdang-scraper/scripts/fetch_dangdang.py --pages 2 --output /tmp/dangdang_books.json
```
说明：`--pages 2` 代表抓取前两页（每页20本，共40本）。

### 第二步：检查并创建飞书多维表格
使用 `feishu_bitable_app_table` 和 `feishu_bitable_app_table_field` 工具：
1. 检查是否存在目标表格，若不存在则创建。
2. 确保包含以下字段：
   - `图书名称` (多行文本)
   - `评论数量` (单行文本)
   - `作者` (单行文本)
   - `出版社` (单行文本)
   - `图书购买链接` (超链接, type: 15)

### 第三步：批量写入多维表格
使用 Node.js 脚本或 Python 脚本将上一步产生的 JSON 数据转换成飞书需要的 `records` 结构，并调用工具 `feishu_bitable_app_table_record` (action: `batch_create`) 批量导入。
注意超链接字段的格式应为 `{"link": "...", "text": "..."}`。

## 注意事项
- 当当封面图片的防盗链和跨域机制较为复杂，如果系统限制了上传外部图片作为附件，建议仅保存图片链接或者跳过封面字段（只保留商品链接即可）。
- 在执行脚本时，注意捕捉由于网络不稳定可能带来的异常，如果一页抓取失败可以重试。
